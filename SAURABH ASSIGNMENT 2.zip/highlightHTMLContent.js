function highlightHTMLContent(htmlContent, plainText, plainTextPositions) {
  const openingTagRegex = /<[^>]+>/g;
  const closingTagRegex = /<\/[^>]+>/g;
  const openingTags = htmlContent.match(openingTagRegex);
  const closingTags = htmlContent.match(closingTagRegex);

  let plainTextIndex = 0;
  let highlightedHtmlContent = '';

  for (let i = 0; i < plainTextPositions.length; i++) {
    const { start, end } = plainTextPositions[i];

    // Add the content between the last position and the current position
    highlightedHtmlContent += htmlContent.slice(plainTextIndex, start);

    // Add the opening tags that were missed
    while (openingTags && plainTextIndex < start) {
      highlightedHtmlContent += openingTags.shift();
      plainTextIndex = htmlContent.indexOf(openingTags[0], plainTextIndex) + openingTags[0].length;
    }

    // Highlight the content between start and end positions
    highlightedHtmlContent += `<mark>${htmlContent.slice(start, end)}</mark>`;
    plainTextIndex = end;

    // Add the closing tags that were missed
    while (closingTags && plainTextIndex >= end) {
      highlightedHtmlContent += closingTags.shift();
      plainTextIndex = htmlContent.indexOf(closingTags[0], plainTextIndex) + closingTags[0].length;
    }
  }

  // Add the remaining content after the last highlight
  highlightedHtmlContent += htmlContent.slice(plainTextIndex);

  return highlightedHtmlContent;
}
