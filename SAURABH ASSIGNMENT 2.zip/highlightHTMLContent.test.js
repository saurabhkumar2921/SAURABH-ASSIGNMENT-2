const { test, expect } = require('@jest/globals');
const highlightHTMLContent = require('./highlightHTMLContent'); 

test('Highlight plainTextPositions in htmlContent', () => {
  const htmlContent = '<p>Some sample text with <strong>highlighted</strong> words.</p>';
  const plainText = 'Some sample text with highlighted words.';
  const plainTextPositions = [
    { start: 4, end: 10 },
    { start: 24, end: 33 }
  ];
  const expectedHighlightedContent = '<p><mark>Some</mark> sample text with <strong>highlighted</strong> <mark>words.</mark></p>';
  
  const highlightedContent = highlightHTMLContent(htmlContent, plainText, plainTextPositions);
  expect(highlightedContent).toBe(expectedHighlightedContent);
});
